<?php
require_once (dirname(dirname(__FILE__)) . '/pageterm.class.php');
class PageTerm_mysql extends PageTerm {}