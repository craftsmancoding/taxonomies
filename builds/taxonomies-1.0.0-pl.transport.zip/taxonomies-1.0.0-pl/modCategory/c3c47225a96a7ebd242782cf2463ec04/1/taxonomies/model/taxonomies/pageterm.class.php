<?php
class PageTerm extends xPDOSimpleObject {}