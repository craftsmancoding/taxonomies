<?php

$xpdo_meta_map = array (
  'modResource' => 
  array (
    0 => 'Taxonomy',
    1 => 'Term',
  ),
  'xPDOSimpleObject' => 
  array (
    0 => 'PageTerm',
  ),
);