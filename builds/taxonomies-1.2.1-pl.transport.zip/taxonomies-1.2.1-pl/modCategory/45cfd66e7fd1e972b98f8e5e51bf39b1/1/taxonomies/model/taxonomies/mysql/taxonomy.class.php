<?php
require_once (dirname(dirname(__FILE__)) . '/taxonomy.class.php');
class Taxonomy_mysql extends Taxonomy {}